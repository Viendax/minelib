# VoxelArt Libre

Pack d'assets complet pour un jeu voxel au style proche de Minecraft, **sans aucun fichier de Mojang**.
Toutes les licences sont compatibles avec un jeu sous **GPLv3**.

## Contenu

| Dossier | Contenu |
|---|---|
| `textures/blocks/` | 594 textures de blocs 16×16 (Pixel Perfection) |
| `textures/items/` | 395 textures d'objets |
| `textures/entity/` | 91 textures de créatures et d'objets 3D : vache, cochon, mouton, poulet, loup, renard, lapins, ours polaire, chevaux, âne, mule, chats, chauve-souris, calmar, araignées, zombie, momie, squelettes, slimes, sorcière, coffres, lits, panneaux, bateaux, wagonnet, porte-armure, flèche, orbe d'XP… |
| `textures/gui/` | interface : barre d'objets, cœurs, nourriture, armure, air, XP, boutons, fenêtres, viseur… |
| `textures/environment/` | soleil, 8 phases de lune, nuages, pluie, neige |
| `textures/particles/` | 18 particules |
| `sounds/` | 144 bruitages + 8 musiques |
| `fonts/` | 4 polices pixel (accents français, majuscules) |

Aperçus : `preview_blocks.png`, `preview_items.png`, `preview_entities.png`, `preview_gui.png`.

Les noms de fichiers suivent la convention des packs de ressources récents (`oak_log.png`,
`grass_block_top.png`, `stone_bricks.png`…). Les textures de `entity/` utilisent le même dépliage
UV que les modèles de Minecraft : ton jeu doit avoir des modèles avec le même découpage pour les utiliser.

## Licences

| Licence | Fichiers | Ce que tu dois faire |
|---|---|---|
| **CC BY-SA 4.0** | les textures Pixel Perfection, le métier à tisser, les baies | Garder `CREDITS.txt` avec le jeu. Si tu modifies ces textures, tes versions modifiées doivent rester sous CC BY-SA 4.0 ou sous GPLv3 (Creative Commons déclare la CC BY-SA 4.0 compatible avec la GPLv3). |
| **CC0** | tout le reste : sons, musiques, polices, interface, ciel, particules, items Auseawesome | Rien. |

`LICENSES.csv` donne la licence, l'auteur, la source et les modifications de **chaque fichier**.
`licenses/` contient les textes complets.

## Contrôle « aucun fichier Mojang »

Les mises à jour communautaires de Pixel Perfection contiennent des textures copiées de Minecraft.
Chaque texture du pack a été comparée aux textures officielles de Minecraft 1.13.2, 1.16.5 et 1.21.1 :
pixels identiques, quasi-copies, recolorations, versions renommées ou retournées. Les cas douteux ont
été vérifiés à l'œil. Toutes les copies ont été retirées (liste dans `EXCLUDED.txt`).
Les seules alertes restantes sont `energy_dust_overlay.png` (image entièrement transparente) et les
boutons de l'interface (simples rectangles en relief dessinés pour ce pack).

## Ce qui a été retiré

Voir `EXCLUDED.txt` :
- les copies de textures Minecraft ;
- les éléments trop typés Minecraft : blocs de commande, End, chorus, purpur, shulker, balise,
  portails, disques, Creeper, Enderman, villageois, golem de fer, Steve/Alex… ;
- les éléments dont une partie était copiée et qui n'ont pas pu être complétés proprement :
  bambou, ruches et nids d'abeilles, bloc de miel, meule, pupitre, table de forgeron, chaîne,
  œuf de tortue, cornichon de mer, trident ;
- les variantes et anciens noms en double de Pixel Perfection.

## Ce que le pack ne contient pas

- **Le skin du joueur** : celui de Pixel Perfection est un Steve redessiné, donc retiré. Il faut en créer un.
- Certaines textures identiques sont voulues : les bords des vitres colorées (`*_stained_glass_pane_top`)
  sont les mêmes pour toutes les couleurs, comme dans l'original.
