# VoxelArt Libre

Pack d'assets complet pour un jeu voxel **qui n'est pas Minecraft** : textures, interface,
ciel, particules, sons, musiques et polices. Aucun fichier de Mojang.
Toutes les licences sont compatibles avec un jeu sous **GPLv3** (CC BY 4.0 et CC0 uniquement).

## Contenu

| Dossier | Contenu |
|---|---|
| `textures/blocks/` | 397 textures de blocs 16×16 |
| `textures/items/` | 262 textures d'objets |
| `textures/gui/` | 33 éléments d'interface : barre d'objets, case sélectionnée, cases d'inventaire, cœurs / nourriture / armure / air (plein, moitié, vide), barre d'expérience, boutons, fenêtres 9-slice, flèche et flamme de progression, curseur, viseur, cases à cocher, glissière, fond de menu |
| `textures/environment/` | soleil, 8 phases de lune, nuages, pluie, neige |
| `textures/particles/` | 18 particules 8×8 : fumée, flamme, étincelle, bulle, gouttes, éclaboussure, flocon, cœur, note, poussière, orbe d'XP, magie, disparition, dégâts |
| `sounds/` | 144 bruitages (mono, prêts pour le son 3D) |
| `sounds/music/` | 8 musiques (environ 18 min au total) |
| `fonts/` | 4 polices pixel (accents français inclus, majuscules uniquement) |

Aperçus : `preview_blocks.png`, `preview_items.png`, `preview_gui.png`.

## Sons, rangés par usage

- `step/` pas : grass, stone, wood, gravel, dirt, sand, snow, cloth
- `dig/` bloc cassé : stone, wood, dirt, gravel, sand, snow, plant, glass, metal
- `hit/` coups pendant le minage, `place/` bloc posé
- `player/` blessure, mort, manger, chute, plouf, nage, souffle, attaque
- `item/` ramasser, lâcher, outil cassé, équiper, pièces, livre, fabrication, enclume
- `block/` portes, trappes, coffre, bouton, levier, plaque, feu, explosions, mèche (boucle), feux d'artifice, cloche, note
- `mob/` monstre, slime, animal, chien, loup, insecte…
- `ui/` clic, survol, retour, ouvrir, fermer, erreur, confirmer, niveau supérieur…

Quand il y a `_1`, `_2`… : ce sont des variantes à tirer au hasard pour éviter la répétition.

## Licences

- **ProgrammerArt (la plupart des blocs et items) : CC BY 4.0.** Compatible GPLv3 ;
  seule obligation : garder `CREDITS.txt` (ou une mention équivalente) avec ton jeu.
- **Tout le reste : CC0** (domaine public), aucune obligation.
- Les assets gardent leur licence : écris « code sous GPLv3, assets sous CC BY 4.0 / CC0 (voir CREDITS.txt) ».
- `LICENSES.csv` : licence, auteur, source et modifications pour **chacun des fichiers**.
  `licenses/` : textes complets.

## Une texture par élément

Un nom de fichier = un élément. Plusieurs fichiers pour un même élément seulement quand il en faut
plusieurs : faces (`_top`, `_side`, `_bottom`), stades de pousse, états on/off, dégâts,
fissures de minage (`destroy_stage_0…9`). Animations : `water_flow.png` (2 images) et
`items/compass.png` (8 images). Aucun fichier n'est une copie d'un autre.

## Ce qui a été retiré

Voir `EXCLUDED.txt` : éléments trop typés Minecraft (blocs de commande, End, disques, têtes de
Steve/Creeper…), copies identiques, doublons entre sources, et deux sons Freesound de licence incertaine.

## Ce que le pack ne contient pas

- **Les textures des créatures et du joueur** : elles dépendent entièrement des modèles 3D de ton jeu
  (le dépliage UV change d'un jeu à l'autre), donc il faut les faire avec tes modèles.
- Le style de ProgrammerArt est simple ; les items d'Auseawesome sont plus détaillés.
